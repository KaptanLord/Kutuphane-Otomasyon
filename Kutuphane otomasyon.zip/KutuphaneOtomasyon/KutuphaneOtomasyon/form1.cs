﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class login_panel : Form
    {

        List<Kisi> kisilerim = new List<Kisi>();
        List<Kitap> kitaps= new List<Kitap>();
        

        public login_panel()
        {
            InitializeComponent();
        }

        private void btn_temizle_Click(object sender, EventArgs e)
        {
            txt_kullaniciAdi.Text = string.Empty;
            txt_sifre.Text = string.Empty;
        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            string kullaniciAdi, Sifre = "";

            kullaniciAdi = txt_kullaniciAdi.Text;
            Sifre = txt_sifre.Text;

            bool kontrol = false;

            foreach (Kisi kisi in kisilerim)
            {
                if (kullaniciAdi.ToLower() == kisi.getKullaniciadi() && Sifre.ToLower() == kisi.getSifre() && kisi.getYetki() == "admin")
                {
                    //admin sayfasına yönlendir
                    adminsayfasi adminsayfasi = new adminsayfasi(kisilerim,kitaps);
                    adminsayfasi.Show();
                    this.Hide();
                    kontrol = true;
                    break;
                }
                else if (kullaniciAdi.ToLower() == kisi.getKullaniciadi() && Sifre.ToLower() == kisi.getSifre() && kisi.getYetki() == "uye")
                {
                    uyesayfasi uyesayfasi = new uyesayfasi(kitaps);
                    uyesayfasi.Show();
                    this.Hide();
                    kontrol = true;
                    break;
                }


            }

            if (!kontrol)
            {
                MessageBox.Show("Hatalı Giriş Yaptınız!!!");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            kisilerim.Add(new Kisi(1, "Kaptan", "Lord", DateTime.Now, "kaptan", "1", "admin"));
            kisilerim.Add(new Kisi(2, "Murat", "Özcan", DateTime.Now, "murat", "2", "uye"));
            kisilerim.Add(new Kisi(3, "Berke", "Özcan", DateTime.Now, "berke", "3", "uye"));
            kisilerim.Add(new Kisi(4, "Kadir", "Turhan", DateTime.Now, "kadir", "4", "uye"));


            kitaps.Add(new Kitap(1, "İçimizdeki Şeytan", "Sebahattin Ali", "Türkçe", "Yapı Kredi Yayınları", "Roman", 100, 250, 2016));
            kitaps.Add(new Kitap(2, "Tutunamayanlar", "Oğuz Atay", "Türkçe", "İletişim Yayıncılık", "Roman", 300, 200, 2018));
            kitaps.Add(new Kitap(3, "Uçurtma Avcısı", "Khaled Hosseini", "İngilizce", "Everest Yayıncılık", "Roman", 100, 350, 2018));
            kitaps.Add(new Kitap(4, "Küçük Prens", "Antine de Saint Exupery", "İngilizce", "Can Çocuk Yayınları", "Roman", 50, 60, 2010));
            kitaps.Add(new Kitap(5, "Kürk Mantolu Adam", "Sebahattin Ali", "Türkçe", "Yapı Kredi Yayınları", "Roman", 650, 220, 2015));
        }
    }
}
