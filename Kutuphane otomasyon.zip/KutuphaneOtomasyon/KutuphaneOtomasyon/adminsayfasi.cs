﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class adminsayfasi : Form
    {
        List<Kisi> kisilerim;
        List<Kitap> kitaplarım;
        public adminsayfasi(List<Kisi> kisilerim, List<Kitap> kitaplarım)

        {
            InitializeComponent();
            this.kisilerim = kisilerim;
            this.kitaplarım = kitaplarım;
        }

        private void adminsayfasi_Load(object sender, EventArgs e)
        {
            foreach (Kisi kisi in kisilerim)
            {
                dgv_uyeler.Rows.Add(kisi.getid(), kisi.getisim(), kisi.getSoyisim(), kisi.getOlustumatarih(), kisi.getKullaniciadi(), kisi.getSifre(), kisi.getYetki());
            }

            foreach (Kitap kitap in kitaplarım)
            {
                dgv_kitaplar.Rows.Add(kitap.getKitapid(), kitap.getKitapisim(), kitap.getKitapyazar(), kitap.getKitapdili(), kitap.getYayinevi(), kitap.getTur(), kitap.getAdet(), kitap.getSayfasayisi(), kitap.getBasimyili());
            }
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            dgv_uyeler.Rows.Add(Convert.ToInt32(txt_id.Text), txt_isim.Text, txt_soyisim.Text, maskedTextBox1.Text, txt_kullaniciadi.Text, txt_sifre.Text, txt_yetki.Text);
        }

        private void btn_sil_Click(object sender, EventArgs e)
        {
            dgv_uyeler.Rows.Remove(dgv_uyeler.CurrentRow);
        }
        public void textleridoldur()
        {

            txt_id.Text = dgv_uyeler.CurrentRow.Cells[0].Value.ToString();
            txt_isim.Text = dgv_uyeler.CurrentRow.Cells[1].Value.ToString();
            txt_soyisim.Text = dgv_uyeler.CurrentRow.Cells[2].Value.ToString();
            maskedTextBox1.Text = dgv_uyeler.CurrentRow.Cells[3].Value.ToString();
            txt_kullaniciadi.Text = dgv_uyeler.CurrentRow.Cells[4].Value.ToString();
            txt_sifre.Text = dgv_uyeler.CurrentRow.Cells[5].Value.ToString();
            txt_yetki.Text = dgv_uyeler.CurrentRow.Cells[6].Value.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textleridoldur();
        }

        private void btn_guncelle_Click(object sender, EventArgs e)
        {
            string id = txt_id.Text;
            string isim = txt_isim.Text;
            string soyisim = txt_soyisim.Text;
            string tarih = maskedTextBox1.Text;
            string kullaniciadi = txt_kullaniciadi.Text;
            string sifre = txt_sifre.Text;
            string yetki = txt_yetki.Text;

            dgv_uyeler.Rows.Remove(dgv_uyeler.CurrentRow);
            dgv_uyeler.Rows.Add(id, isim, soyisim, tarih, kullaniciadi, sifre, yetki);
        }

        private void btn_temizle_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < groupBox_uyeislemleri.Controls.Count; i++)
            {
                if (groupBox_uyeislemleri.Controls[i] is TextBox || groupBox_uyeislemleri.Controls[i] is MaskedTextBox)
                {
                    groupBox_uyeislemleri.Controls[i].Text = string.Empty;
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void btn_kitapekle_Click(object sender, EventArgs e)
        {
            dgv_kitaplar.Rows.Add(txt_kitapid.Text, txt_kitapisim.Text, txt_kitapyazar.Text, txt_dil.Text, txt_yayinevi.Text, txt_tur.Text, txt_adet.Text, txt_sayfa.Text, txt_basimyili.Text);
        }

        private void btn_kitapsil_Click(object sender, EventArgs e)
        {
            dgv_kitaplar.Rows.Remove(dgv_kitaplar.CurrentRow);
        }

        private void btn_kitapguncelle_Click(object sender, EventArgs e)
        {
            string kitapid = txt_kitapid.Text;
            string kitapismi = txt_kitapisim.Text;
            string kitapYazar = txt_kitapyazar.Text;
            string kitapDili = txt_dil.Text;
            string yayinevi = txt_yayinevi.Text;
            string tur = txt_tur.Text;
            string adet = txt_adet.Text;
            string sayfa = txt_sayfa.Text;
            string basimyili = txt_basimyili.Text;

            dgv_kitaplar.Rows.Remove(dgv_kitaplar.CurrentRow);
            dgv_kitaplar.Rows.Add(kitapid, kitapismi, kitapYazar, kitapDili, yayinevi, tur, adet, sayfa, basimyili);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_kitapid.Text = dgv_kitaplar.CurrentRow.Cells[0].Value.ToString();
            txt_kitapisim.Text = dgv_kitaplar.CurrentRow.Cells[1].Value.ToString();
            txt_kitapyazar.Text = dgv_kitaplar.CurrentRow.Cells[2].Value.ToString();
            txt_dil.Text = dgv_kitaplar.CurrentRow.Cells[3].Value.ToString();
            txt_yayinevi.Text = dgv_kitaplar.CurrentRow.Cells[4].Value.ToString();
            txt_tur.Text = dgv_kitaplar.CurrentRow.Cells[5].Value.ToString();
            txt_adet.Text = dgv_kitaplar.CurrentRow.Cells[6].Value.ToString();
            txt_sayfa.Text = dgv_kitaplar.CurrentRow.Cells[7].Value.ToString();
            txt_basimyili.Text = dgv_kitaplar.CurrentRow.Cells[8].Value.ToString();
        }

        private void btn_tamizle_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < groupBox_kitap.Controls.Count; i++)
            {
                if (groupBox_kitap.Controls[i] is TextBox)
                {
                    groupBox_kitap.Controls[i].Text = string.Empty;
                }
            }
        }

        private void btn_ara_Click(object sender, EventArgs e)
        {
            Kisi hedefkisi = null;

            int secilenkisiID = Convert.ToInt32(txt_ara.Text);

            foreach (Kisi kisi in kisilerim)
            {
                if (kisi.getid() == secilenkisiID)
                {
                    hedefkisi = kisi;
                    break;
                }
            }

            dgv_uyeler.Rows.Clear();
            dgv_uyeler.Rows.Add(hedefkisi.getid(), hedefkisi.getisim(), hedefkisi.getSoyisim(), hedefkisi.getOlustumatarih(), hedefkisi.getKullaniciadi(), hedefkisi.getSifre(), hedefkisi.getYetki());

        }

        private void btn_yenile_Click(object sender, EventArgs e)
        {
            dgv_uyeler.Rows.Remove(dgv_uyeler.CurrentRow);
            foreach (Kisi hedefkisi in kisilerim)
            {
                dgv_uyeler.Rows.Add(hedefkisi.getid(), hedefkisi.getisim(), hedefkisi.getSoyisim(), hedefkisi.getOlustumatarih(), hedefkisi.getKullaniciadi(), hedefkisi.getSifre(), hedefkisi.getYetki());
            }
        }

        private void btn_kitapara_Click(object sender, EventArgs e)
        {
            Kitap hedefkitap = null;

            int secilenkitapID=Convert.ToInt32(txt_kitapara.Text);

            foreach (Kitap kitap in kitaplarım)
            {
                if (kitap.getKitapid()==secilenkitapID)
                {
                    hedefkitap = kitap;
                    break;
                }
            }

            dgv_kitaplar.Rows.Clear();
            dgv_kitaplar.Rows.Add(hedefkitap.getKitapid(), hedefkitap.getTur(), hedefkitap.getYayinevi(), hedefkitap.getSayfasayisi(), hedefkitap.getKitapyazar(), hedefkitap.getAdet(), hedefkitap.getBasimyili(), hedefkitap.getKitapdili(), hedefkitap.getKitapisim());
        }

        private void btn_kitapyenile_Click(object sender, EventArgs e)
        {
            dgv_kitaplar.Rows.Remove(dgv_kitaplar.CurrentRow);
            foreach (Kitap hedefkitap in kitaplarım)
            {
                dgv_kitaplar.Rows.Add(hedefkitap.getKitapid(), hedefkitap.getTur(), hedefkitap.getYayinevi(), hedefkitap.getSayfasayisi(), hedefkitap.getKitapyazar(), hedefkitap.getAdet(), hedefkitap.getBasimyili(), hedefkitap.getKitapdili(), hedefkitap.getKitapisim());
            }
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            login_panel loginpanel = new login_panel();
            loginpanel.Show();
            this.Hide();
        }
    }
}
