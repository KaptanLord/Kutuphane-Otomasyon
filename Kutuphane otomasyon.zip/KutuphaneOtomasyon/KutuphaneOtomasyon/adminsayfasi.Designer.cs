﻿namespace KutuphaneOtomasyon
{
    partial class adminsayfasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_uyeislemleri = new System.Windows.Forms.GroupBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.btn_temizle = new System.Windows.Forms.Button();
            this.btn_guncelle = new System.Windows.Forms.Button();
            this.btn_sil = new System.Windows.Forms.Button();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.txt_yetki = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_sifre = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_kullaniciadi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_soyisim = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_isim = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv_uyeler = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.isim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soyisim = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.olusturmatarih = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kullaniciadi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sifre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yetki = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.dgv_kitaplar = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ADET = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SAYFA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.basimyili = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox_kitap = new System.Windows.Forms.GroupBox();
            this.txt_basimyili = new System.Windows.Forms.TextBox();
            this.txt_sayfa = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_tur = new System.Windows.Forms.TextBox();
            this.btn_tamizle = new System.Windows.Forms.Button();
            this.btn_kitapguncelle = new System.Windows.Forms.Button();
            this.btn_kitapsil = new System.Windows.Forms.Button();
            this.btn_kitapekle = new System.Windows.Forms.Button();
            this.txt_dil = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_adet = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_kitapyazar = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_yayinevi = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_kitapisim = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_kitapid = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btn_ara = new System.Windows.Forms.Button();
            this.txt_ara = new System.Windows.Forms.TextBox();
            this.btn_yenile = new System.Windows.Forms.Button();
            this.txt_kitapara = new System.Windows.Forms.TextBox();
            this.btn_kitapyenile = new System.Windows.Forms.Button();
            this.btn_kitapara = new System.Windows.Forms.Button();
            this.btn_cikis = new System.Windows.Forms.Button();
            this.groupBox_uyeislemleri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_uyeler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_kitaplar)).BeginInit();
            this.groupBox_kitap.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_uyeislemleri
            // 
            this.groupBox_uyeislemleri.Controls.Add(this.maskedTextBox1);
            this.groupBox_uyeislemleri.Controls.Add(this.btn_temizle);
            this.groupBox_uyeislemleri.Controls.Add(this.btn_guncelle);
            this.groupBox_uyeislemleri.Controls.Add(this.btn_sil);
            this.groupBox_uyeislemleri.Controls.Add(this.btn_ekle);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_yetki);
            this.groupBox_uyeislemleri.Controls.Add(this.label7);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_sifre);
            this.groupBox_uyeislemleri.Controls.Add(this.label6);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_kullaniciadi);
            this.groupBox_uyeislemleri.Controls.Add(this.label5);
            this.groupBox_uyeislemleri.Controls.Add(this.label4);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_soyisim);
            this.groupBox_uyeislemleri.Controls.Add(this.label3);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_isim);
            this.groupBox_uyeislemleri.Controls.Add(this.label2);
            this.groupBox_uyeislemleri.Controls.Add(this.txt_id);
            this.groupBox_uyeislemleri.Controls.Add(this.label1);
            this.groupBox_uyeislemleri.Location = new System.Drawing.Point(12, 233);
            this.groupBox_uyeislemleri.Name = "groupBox_uyeislemleri";
            this.groupBox_uyeislemleri.Size = new System.Drawing.Size(604, 359);
            this.groupBox_uyeislemleri.TabIndex = 0;
            this.groupBox_uyeislemleri.TabStop = false;
            this.groupBox_uyeislemleri.Text = "Üye İşlemleri";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(364, 66);
            this.maskedTextBox1.Mask = "00/00/0000 90:00";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(161, 20);
            this.maskedTextBox1.TabIndex = 18;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // btn_temizle
            // 
            this.btn_temizle.Location = new System.Drawing.Point(6, 318);
            this.btn_temizle.Name = "btn_temizle";
            this.btn_temizle.Size = new System.Drawing.Size(226, 36);
            this.btn_temizle.TabIndex = 17;
            this.btn_temizle.Text = "Temizle";
            this.btn_temizle.UseVisualStyleBackColor = true;
            this.btn_temizle.Click += new System.EventHandler(this.btn_temizle_Click);
            // 
            // btn_guncelle
            // 
            this.btn_guncelle.Location = new System.Drawing.Point(6, 276);
            this.btn_guncelle.Name = "btn_guncelle";
            this.btn_guncelle.Size = new System.Drawing.Size(226, 36);
            this.btn_guncelle.TabIndex = 16;
            this.btn_guncelle.Text = "Güncelle";
            this.btn_guncelle.UseVisualStyleBackColor = true;
            this.btn_guncelle.Click += new System.EventHandler(this.btn_guncelle_Click);
            // 
            // btn_sil
            // 
            this.btn_sil.Location = new System.Drawing.Point(6, 234);
            this.btn_sil.Name = "btn_sil";
            this.btn_sil.Size = new System.Drawing.Size(226, 36);
            this.btn_sil.TabIndex = 15;
            this.btn_sil.Text = "Sil";
            this.btn_sil.UseVisualStyleBackColor = true;
            this.btn_sil.Click += new System.EventHandler(this.btn_sil_Click);
            // 
            // btn_ekle
            // 
            this.btn_ekle.Location = new System.Drawing.Point(6, 192);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(226, 36);
            this.btn_ekle.TabIndex = 14;
            this.btn_ekle.Text = "Ekle";
            this.btn_ekle.UseVisualStyleBackColor = true;
            this.btn_ekle.Click += new System.EventHandler(this.btn_ekle_Click);
            // 
            // txt_yetki
            // 
            this.txt_yetki.Location = new System.Drawing.Point(94, 138);
            this.txt_yetki.Name = "txt_yetki";
            this.txt_yetki.Size = new System.Drawing.Size(161, 20);
            this.txt_yetki.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Yetki";
            // 
            // txt_sifre
            // 
            this.txt_sifre.Location = new System.Drawing.Point(364, 104);
            this.txt_sifre.Name = "txt_sifre";
            this.txt_sifre.Size = new System.Drawing.Size(161, 20);
            this.txt_sifre.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(277, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Şifre";
            // 
            // txt_kullaniciadi
            // 
            this.txt_kullaniciadi.Location = new System.Drawing.Point(94, 101);
            this.txt_kullaniciadi.Name = "txt_kullaniciadi";
            this.txt_kullaniciadi.Size = new System.Drawing.Size(161, 20);
            this.txt_kullaniciadi.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Kullanıcı Adı";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(275, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Oluşturma Tarihi";
            // 
            // txt_soyisim
            // 
            this.txt_soyisim.Location = new System.Drawing.Point(94, 63);
            this.txt_soyisim.Name = "txt_soyisim";
            this.txt_soyisim.Size = new System.Drawing.Size(161, 20);
            this.txt_soyisim.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Soyisim :";
            // 
            // txt_isim
            // 
            this.txt_isim.Location = new System.Drawing.Point(364, 27);
            this.txt_isim.Name = "txt_isim";
            this.txt_isim.Size = new System.Drawing.Size(161, 20);
            this.txt_isim.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(277, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "İsim :";
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(94, 27);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(161, 20);
            this.txt_id.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "İd :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(341, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 25);
            this.label8.TabIndex = 1;
            this.label8.Text = "ÜYELER";
            // 
            // dgv_uyeler
            // 
            this.dgv_uyeler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_uyeler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.isim,
            this.soyisim,
            this.olusturmatarih,
            this.kullaniciadi,
            this.sifre,
            this.yetki});
            this.dgv_uyeler.Location = new System.Drawing.Point(12, 37);
            this.dgv_uyeler.Name = "dgv_uyeler";
            this.dgv_uyeler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_uyeler.Size = new System.Drawing.Size(604, 190);
            this.dgv_uyeler.TabIndex = 2;
            this.dgv_uyeler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dgv_uyeler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.id.HeaderText = "İD";
            this.id.Name = "id";
            this.id.Width = 43;
            // 
            // isim
            // 
            this.isim.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.isim.HeaderText = "İSİM";
            this.isim.Name = "isim";
            this.isim.Width = 54;
            // 
            // soyisim
            // 
            this.soyisim.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.soyisim.HeaderText = "SOYİSİM";
            this.soyisim.Name = "soyisim";
            this.soyisim.Width = 76;
            // 
            // olusturmatarih
            // 
            this.olusturmatarih.HeaderText = "OLUŞTURMA TARİHİ";
            this.olusturmatarih.Name = "olusturmatarih";
            // 
            // kullaniciadi
            // 
            this.kullaniciadi.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.kullaniciadi.HeaderText = "KULLANICI ADI";
            this.kullaniciadi.Name = "kullaniciadi";
            this.kullaniciadi.Width = 99;
            // 
            // sifre
            // 
            this.sifre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.sifre.HeaderText = "ŞİFRE";
            this.sifre.Name = "sifre";
            this.sifre.Width = 63;
            // 
            // yetki
            // 
            this.yetki.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.yetki.HeaderText = "YETKİ";
            this.yetki.Name = "yetki";
            this.yetki.Width = 63;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(858, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "KİTAPLAR";
            // 
            // dgv_kitaplar
            // 
            this.dgv_kitaplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_kitaplar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.ADET,
            this.SAYFA,
            this.basimyili});
            this.dgv_kitaplar.Location = new System.Drawing.Point(624, 37);
            this.dgv_kitaplar.Name = "dgv_kitaplar";
            this.dgv_kitaplar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_kitaplar.Size = new System.Drawing.Size(622, 190);
            this.dgv_kitaplar.TabIndex = 4;
            this.dgv_kitaplar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn1.HeaderText = "İD";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 43;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn2.HeaderText = "İSİM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 54;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn3.HeaderText = "YAZAR";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 68;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn4.HeaderText = "DİLİ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 52;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn5.HeaderText = "YAYIN EVİ";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 84;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn6.HeaderText = "TÜRÜ";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 63;
            // 
            // ADET
            // 
            this.ADET.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.ADET.HeaderText = "ADET";
            this.ADET.Name = "ADET";
            this.ADET.Width = 61;
            // 
            // SAYFA
            // 
            this.SAYFA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.SAYFA.HeaderText = "SAYFA";
            this.SAYFA.Name = "SAYFA";
            this.SAYFA.Width = 66;
            // 
            // basimyili
            // 
            this.basimyili.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.basimyili.HeaderText = "BASIM YILI";
            this.basimyili.Name = "basimyili";
            this.basimyili.Width = 87;
            // 
            // groupBox_kitap
            // 
            this.groupBox_kitap.Controls.Add(this.btn_cikis);
            this.groupBox_kitap.Controls.Add(this.txt_basimyili);
            this.groupBox_kitap.Controls.Add(this.txt_sayfa);
            this.groupBox_kitap.Controls.Add(this.label17);
            this.groupBox_kitap.Controls.Add(this.label18);
            this.groupBox_kitap.Controls.Add(this.txt_tur);
            this.groupBox_kitap.Controls.Add(this.btn_tamizle);
            this.groupBox_kitap.Controls.Add(this.btn_kitapguncelle);
            this.groupBox_kitap.Controls.Add(this.btn_kitapsil);
            this.groupBox_kitap.Controls.Add(this.btn_kitapekle);
            this.groupBox_kitap.Controls.Add(this.txt_dil);
            this.groupBox_kitap.Controls.Add(this.label10);
            this.groupBox_kitap.Controls.Add(this.txt_adet);
            this.groupBox_kitap.Controls.Add(this.label11);
            this.groupBox_kitap.Controls.Add(this.txt_kitapyazar);
            this.groupBox_kitap.Controls.Add(this.label12);
            this.groupBox_kitap.Controls.Add(this.label13);
            this.groupBox_kitap.Controls.Add(this.txt_yayinevi);
            this.groupBox_kitap.Controls.Add(this.label14);
            this.groupBox_kitap.Controls.Add(this.txt_kitapisim);
            this.groupBox_kitap.Controls.Add(this.label15);
            this.groupBox_kitap.Controls.Add(this.txt_kitapid);
            this.groupBox_kitap.Controls.Add(this.label16);
            this.groupBox_kitap.Location = new System.Drawing.Point(624, 233);
            this.groupBox_kitap.Name = "groupBox_kitap";
            this.groupBox_kitap.Size = new System.Drawing.Size(604, 359);
            this.groupBox_kitap.TabIndex = 5;
            this.groupBox_kitap.TabStop = false;
            this.groupBox_kitap.Text = "KİTAP İŞLEMLERİ";
            // 
            // txt_basimyili
            // 
            this.txt_basimyili.Location = new System.Drawing.Point(364, 176);
            this.txt_basimyili.Name = "txt_basimyili";
            this.txt_basimyili.Size = new System.Drawing.Size(161, 20);
            this.txt_basimyili.TabIndex = 23;
            // 
            // txt_sayfa
            // 
            this.txt_sayfa.Location = new System.Drawing.Point(364, 141);
            this.txt_sayfa.Name = "txt_sayfa";
            this.txt_sayfa.Size = new System.Drawing.Size(161, 20);
            this.txt_sayfa.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(277, 179);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 13);
            this.label17.TabIndex = 20;
            this.label17.Text = "Basım Yılı";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(275, 144);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 19;
            this.label18.Text = "Sayfa";
            // 
            // txt_tur
            // 
            this.txt_tur.Location = new System.Drawing.Point(364, 66);
            this.txt_tur.Name = "txt_tur";
            this.txt_tur.Size = new System.Drawing.Size(161, 20);
            this.txt_tur.TabIndex = 18;
            // 
            // btn_tamizle
            // 
            this.btn_tamizle.Location = new System.Drawing.Point(6, 318);
            this.btn_tamizle.Name = "btn_tamizle";
            this.btn_tamizle.Size = new System.Drawing.Size(226, 36);
            this.btn_tamizle.TabIndex = 17;
            this.btn_tamizle.Text = "Temizle";
            this.btn_tamizle.UseVisualStyleBackColor = true;
            this.btn_tamizle.Click += new System.EventHandler(this.btn_tamizle_Click);
            // 
            // btn_kitapguncelle
            // 
            this.btn_kitapguncelle.Location = new System.Drawing.Point(6, 276);
            this.btn_kitapguncelle.Name = "btn_kitapguncelle";
            this.btn_kitapguncelle.Size = new System.Drawing.Size(226, 36);
            this.btn_kitapguncelle.TabIndex = 16;
            this.btn_kitapguncelle.Text = "Güncelle";
            this.btn_kitapguncelle.UseVisualStyleBackColor = true;
            this.btn_kitapguncelle.Click += new System.EventHandler(this.btn_kitapguncelle_Click);
            // 
            // btn_kitapsil
            // 
            this.btn_kitapsil.Location = new System.Drawing.Point(6, 234);
            this.btn_kitapsil.Name = "btn_kitapsil";
            this.btn_kitapsil.Size = new System.Drawing.Size(226, 36);
            this.btn_kitapsil.TabIndex = 15;
            this.btn_kitapsil.Text = "Sil";
            this.btn_kitapsil.UseVisualStyleBackColor = true;
            this.btn_kitapsil.Click += new System.EventHandler(this.btn_kitapsil_Click);
            // 
            // btn_kitapekle
            // 
            this.btn_kitapekle.Location = new System.Drawing.Point(6, 192);
            this.btn_kitapekle.Name = "btn_kitapekle";
            this.btn_kitapekle.Size = new System.Drawing.Size(226, 36);
            this.btn_kitapekle.TabIndex = 14;
            this.btn_kitapekle.Text = "Ekle";
            this.btn_kitapekle.UseVisualStyleBackColor = true;
            this.btn_kitapekle.Click += new System.EventHandler(this.btn_kitapekle_Click);
            // 
            // txt_dil
            // 
            this.txt_dil.Location = new System.Drawing.Point(94, 138);
            this.txt_dil.Name = "txt_dil";
            this.txt_dil.Size = new System.Drawing.Size(161, 20);
            this.txt_dil.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 141);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Dil";
            // 
            // txt_adet
            // 
            this.txt_adet.Location = new System.Drawing.Point(364, 104);
            this.txt_adet.Name = "txt_adet";
            this.txt_adet.Size = new System.Drawing.Size(161, 20);
            this.txt_adet.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(277, 104);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Adet";
            // 
            // txt_kitapyazar
            // 
            this.txt_kitapyazar.Location = new System.Drawing.Point(94, 101);
            this.txt_kitapyazar.Name = "txt_kitapyazar";
            this.txt_kitapyazar.Size = new System.Drawing.Size(161, 20);
            this.txt_kitapyazar.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 104);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Kitap Yazarı";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(275, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 13);
            this.label13.TabIndex = 6;
            this.label13.Text = "Tür";
            // 
            // txt_yayinevi
            // 
            this.txt_yayinevi.Location = new System.Drawing.Point(94, 63);
            this.txt_yayinevi.Name = "txt_yayinevi";
            this.txt_yayinevi.Size = new System.Drawing.Size(161, 20);
            this.txt_yayinevi.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "Yayın Evi";
            // 
            // txt_kitapisim
            // 
            this.txt_kitapisim.Location = new System.Drawing.Point(364, 27);
            this.txt_kitapisim.Name = "txt_kitapisim";
            this.txt_kitapisim.Size = new System.Drawing.Size(161, 20);
            this.txt_kitapisim.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(277, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Kitap İsim";
            // 
            // txt_kitapid
            // 
            this.txt_kitapid.Location = new System.Drawing.Point(94, 27);
            this.txt_kitapid.Name = "txt_kitapid";
            this.txt_kitapid.Size = new System.Drawing.Size(161, 20);
            this.txt_kitapid.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "İd :";
            // 
            // btn_ara
            // 
            this.btn_ara.Location = new System.Drawing.Point(12, 9);
            this.btn_ara.Name = "btn_ara";
            this.btn_ara.Size = new System.Drawing.Size(55, 24);
            this.btn_ara.TabIndex = 6;
            this.btn_ara.Text = "Ara";
            this.btn_ara.UseVisualStyleBackColor = true;
            this.btn_ara.Click += new System.EventHandler(this.btn_ara_Click);
            // 
            // txt_ara
            // 
            this.txt_ara.Location = new System.Drawing.Point(73, 11);
            this.txt_ara.Name = "txt_ara";
            this.txt_ara.Size = new System.Drawing.Size(77, 20);
            this.txt_ara.TabIndex = 7;
            // 
            // btn_yenile
            // 
            this.btn_yenile.Location = new System.Drawing.Point(156, 8);
            this.btn_yenile.Name = "btn_yenile";
            this.btn_yenile.Size = new System.Drawing.Size(55, 24);
            this.btn_yenile.TabIndex = 6;
            this.btn_yenile.Text = "Yenile";
            this.btn_yenile.UseVisualStyleBackColor = true;
            this.btn_yenile.Click += new System.EventHandler(this.btn_yenile_Click);
            // 
            // txt_kitapara
            // 
            this.txt_kitapara.Location = new System.Drawing.Point(682, 11);
            this.txt_kitapara.Name = "txt_kitapara";
            this.txt_kitapara.Size = new System.Drawing.Size(77, 20);
            this.txt_kitapara.TabIndex = 10;
            // 
            // btn_kitapyenile
            // 
            this.btn_kitapyenile.Location = new System.Drawing.Point(765, 8);
            this.btn_kitapyenile.Name = "btn_kitapyenile";
            this.btn_kitapyenile.Size = new System.Drawing.Size(55, 24);
            this.btn_kitapyenile.TabIndex = 8;
            this.btn_kitapyenile.Text = "Yenile";
            this.btn_kitapyenile.UseVisualStyleBackColor = true;
            this.btn_kitapyenile.Click += new System.EventHandler(this.btn_kitapyenile_Click);
            // 
            // btn_kitapara
            // 
            this.btn_kitapara.Location = new System.Drawing.Point(621, 9);
            this.btn_kitapara.Name = "btn_kitapara";
            this.btn_kitapara.Size = new System.Drawing.Size(55, 24);
            this.btn_kitapara.TabIndex = 9;
            this.btn_kitapara.Text = "Ara";
            this.btn_kitapara.UseVisualStyleBackColor = true;
            this.btn_kitapara.Click += new System.EventHandler(this.btn_kitapara_Click);
            // 
            // btn_cikis
            // 
            this.btn_cikis.Location = new System.Drawing.Point(508, 321);
            this.btn_cikis.Name = "btn_cikis";
            this.btn_cikis.Size = new System.Drawing.Size(90, 33);
            this.btn_cikis.TabIndex = 24;
            this.btn_cikis.Text = "Çıkış Yap";
            this.btn_cikis.UseVisualStyleBackColor = true;
            this.btn_cikis.Click += new System.EventHandler(this.btn_cikis_Click);
            // 
            // adminsayfasi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 596);
            this.Controls.Add(this.txt_kitapara);
            this.Controls.Add(this.btn_kitapyenile);
            this.Controls.Add(this.btn_kitapara);
            this.Controls.Add(this.txt_ara);
            this.Controls.Add(this.btn_yenile);
            this.Controls.Add(this.btn_ara);
            this.Controls.Add(this.groupBox_kitap);
            this.Controls.Add(this.dgv_kitaplar);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dgv_uyeler);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBox_uyeislemleri);
            this.Name = "adminsayfasi";
            this.Text = "adminsayfasi";
            this.Load += new System.EventHandler(this.adminsayfasi_Load);
            this.groupBox_uyeislemleri.ResumeLayout(false);
            this.groupBox_uyeislemleri.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_uyeler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_kitaplar)).EndInit();
            this.groupBox_kitap.ResumeLayout(false);
            this.groupBox_kitap.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_uyeislemleri;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox txt_yetki;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_sifre;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_kullaniciadi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_soyisim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_isim;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_temizle;
        private System.Windows.Forms.Button btn_guncelle;
        private System.Windows.Forms.Button btn_sil;
        private System.Windows.Forms.Button btn_ekle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgv_uyeler;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn isim;
        private System.Windows.Forms.DataGridViewTextBoxColumn soyisim;
        private System.Windows.Forms.DataGridViewTextBoxColumn olusturmatarih;
        private System.Windows.Forms.DataGridViewTextBoxColumn kullaniciadi;
        private System.Windows.Forms.DataGridViewTextBoxColumn sifre;
        private System.Windows.Forms.DataGridViewTextBoxColumn yetki;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgv_kitaplar;
        private System.Windows.Forms.GroupBox groupBox_kitap;
        private System.Windows.Forms.Button btn_tamizle;
        private System.Windows.Forms.Button btn_kitapguncelle;
        private System.Windows.Forms.Button btn_kitapsil;
        private System.Windows.Forms.Button btn_kitapekle;
        private System.Windows.Forms.TextBox txt_dil;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_adet;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_kitapyazar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_yayinevi;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_kitapid;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_tur;
        private System.Windows.Forms.TextBox txt_kitapisim;
        private System.Windows.Forms.TextBox txt_sayfa;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_basimyili;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ADET;
        private System.Windows.Forms.DataGridViewTextBoxColumn SAYFA;
        private System.Windows.Forms.DataGridViewTextBoxColumn basimyili;
        private System.Windows.Forms.Button btn_ara;
        private System.Windows.Forms.TextBox txt_ara;
        private System.Windows.Forms.Button btn_yenile;
        private System.Windows.Forms.TextBox txt_kitapara;
        private System.Windows.Forms.Button btn_kitapyenile;
        private System.Windows.Forms.Button btn_kitapara;
        private System.Windows.Forms.Button btn_cikis;
    }
}