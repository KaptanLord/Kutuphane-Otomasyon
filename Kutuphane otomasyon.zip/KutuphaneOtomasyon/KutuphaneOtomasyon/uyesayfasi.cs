﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class uyesayfasi : Form
    {
        List<Kitap> kitaplarim;
        public uyesayfasi(List<Kitap> kitaplarim)
        {
            InitializeComponent();
            this.kitaplarim= kitaplarim;
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            login_panel loginpanel=new login_panel();
            loginpanel.Show();
            this.Hide();
        }

        private void uyesayfasi_Load(object sender, EventArgs e)
        {
            foreach (Kitap kitap in kitaplarim)
            {
                dgv_kitaplar2.Rows.Add(kitap.getKitapid(), kitap.getKitapisim(), kitap.getKitapyazar(), kitap.getKitapdili(), kitap.getYayinevi(), kitap.getTur(), kitap.getAdet(), kitap.getSayfasayisi(), kitap.getBasimyili());
            }
        }

        private void btn_ara_Click(object sender, EventArgs e)
        {
            int kitapID = Convert.ToInt32(txt_ara.Text);
            Kitap hedefkitap = null;
            foreach (Kitap kitap in kitaplarim)
            {
                if (kitap.getKitapid() == kitapID)
                {
                    hedefkitap= kitap;
                    
                }
            }

            dgv_kitaplar2.Rows.Clear();
            dgv_kitaplar2.Rows.Add(hedefkitap.getKitapid(), hedefkitap.getKitapisim(), hedefkitap.getKitapyazar(), hedefkitap.getKitapdili(), hedefkitap.getYayinevi(), hedefkitap.getTur(), hedefkitap.getAdet(), hedefkitap.getSayfasayisi(), hedefkitap.getBasimyili());
        }

        private void btn_yenile_Click(object sender, EventArgs e)
        {
            dgv_kitaplar2.Rows.Remove(dgv_kitaplar2.CurrentRow);

            foreach (Kitap hedefkitap in kitaplarim)
            {
                dgv_kitaplar2.Rows.Add(hedefkitap.getKitapid(), hedefkitap.getKitapisim(), hedefkitap.getKitapyazar(), hedefkitap.getKitapdili(), hedefkitap.getYayinevi(), hedefkitap.getTur(), hedefkitap.getAdet(), hedefkitap.getSayfasayisi(), hedefkitap.getBasimyili());
            }
        }
    }
}
